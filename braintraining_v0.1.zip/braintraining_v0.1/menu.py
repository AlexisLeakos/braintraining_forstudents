#############################
# Training (Menu)
# JCY oct 23
# PRO DB PY
#############################

import tkinter as tk
import geo01
import info02
import info05
import database

# exercises array
a_exercise = ["geo01", "info02", "info05"]
albl_image = [None, None, None]  # label (with images) array
a_image = [None, None, None]  # images array
a_title = [None, None, None]  # array of title (ex: GEO01)

dict_games = {"geo01": geo01.open_window_geo_01, "info02": info02.open_window_info_02,
              "info05": info05.open_window_info_05}


# call other windows (exercices)
def exercise(event, exer):
    dict_games[exer](window)


def select_results():
    print("test")  # todo afficher les colomnes corectement
    database.select_where()


# call display_results
def display_result(event):
    # TODO
    # create new window and organise it
    window_results = tk.Toplevel(window)
    window_results.title("Résultats")
    window_results.geometry("1100x900")

    # Upper part
    upper_frame = tk.Frame(window_results)
    upper_frame.pack(pady=20)

    title_label = tk.Label(upper_frame, text="Training: Affichage", font=("Helvetica", 16))
    title_label.pack()

    # Parameters entry form
    parameters_frame = tk.Frame(window_results)
    parameters_frame.pack(pady=20)

    # Labels and Entry widgets for parameters
    parameters_labels = ["Pseudo:", "Exercice:", "Date début:", "Date fin:"]
    parameters_entries = []

    for i, label_text in enumerate(parameters_labels):
        label = tk.Label(parameters_frame, text=label_text, font=("Helvetica", 12))
        label.grid(row=0, column=i, padx=5, pady=5, sticky="e")

        entry = tk.Entry(parameters_frame, font=("Helvetica", 12))
        entry.grid(row=0, column=i + 1, padx=5, pady=5, sticky="w")
        parameters_entries.append(entry)

    # Button to view results
    view_results_button = tk.Button(parameters_frame, text="Voir résultats", command=select_results,
                                    font=("Helvetica", 12))
    view_results_button.grid(row=1, columnspan=len(parameters_labels) + 1, pady=10)

    # Middle part with parameters
    parameters_frame = tk.Frame(window_results)
    parameters_frame.pack(pady=20)

    # Labels for each column
    columns = ["Elève", "Date heure", "Temps", "Exercice", "nb OK", "nb Total", "% réussi"]

    for col in columns:
        label = tk.Label(parameters_frame, text=col, relief=tk.RIDGE, width=15, font=("Helvetica", 12))
        label.grid(row=0, column=columns.index(col))

    # Add sample data (replace this with your actual data)
    sample_data = [
        ["John Doe", "2023-01-01 12:00", "30 min", "Exercise 1", 25, 30, 83],
        # Add more rows as needed
    ]

    for i, data in enumerate(sample_data, start=1):
        for j, value in enumerate(data):
            label = tk.Label(parameters_frame, text=value, relief=tk.RIDGE, width=15, font=("Helvetica", 10))
            label.grid(row=i, column=j)

        # Add a progress bar in the last column
        progress_bar = ttk.Progressbar(parameters_frame, orient="horizontal", length=100, mode="determinate")  # TODO trouver un moyen de montrer en bar de progression
        progress_bar.grid(row=i, column=6, padx=5)

    # Total box
    total_box = tk.Frame(window_results)
    total_box.pack(pady=20)

    total_label = tk.Label(total_box, text="Total", font=("Helvetica", 16))
    total_label.pack()

    # Last part with 5 columns
    last_part_frame = tk.Frame(window_results)
    last_part_frame.pack(pady=20)

    last_part_columns = ["NbLignes", "Temps total", "Nb Total", "% Total"]

    for col in last_part_columns:
        label = tk.Label(last_part_frame, text=col, relief=tk.RIDGE, width=15, font=("Helvetica", 12))
        label.grid(row=0, column=last_part_columns.index(col))

    # Add sample data for the last part (replace this with your actual data)
    last_part_data = ["100", "5 hours", "500", "75%"]

    for j, value in enumerate(last_part_data):
        label = tk.Label(last_part_frame, text=value, relief=tk.RIDGE, width=15, font=("Helvetica", 12))
        label.grid(row=1, column=j)
    print("display_result")


# Main window
window = tk.Tk()
window.title("Training, entrainement cérébral")
window.geometry("1100x900")

# color définition
rgb_color = (139, 201, 194)
hex_color = '#%02x%02x%02x' % rgb_color  # translation in hexa
window.configure(bg=hex_color)
window.grid_columnconfigure((0, 1, 2), minsize=300, weight=1)

# Title création
lbl_title = tk.Label(window, text="TRAINING MENU", font=("Arial", 15))
lbl_title.grid(row=0, column=1, ipady=5, padx=40, pady=40)

# labels creation and positioning
for ex in range(len(a_exercise)):
    a_title[ex] = tk.Label(window, text=a_exercise[ex], font=("Arial", 15))
    a_title[ex].grid(row=1 + 2 * (ex // 3), column=ex % 3, padx=40, pady=10)  # 3 label per row

    a_image[ex] = tk.PhotoImage(file="img/" + a_exercise[ex] + ".gif")  # image name
    albl_image[ex] = tk.Label(window, image=a_image[ex])  # put image on label
    albl_image[ex].grid(row=2 + 2 * (ex // 3), column=ex % 3, padx=40, pady=10)  # 3 label per row
    albl_image[ex].bind("<Button-1>",
                        lambda event, ex=ex: exercise(event=None, exer=a_exercise[ex]))  # link to others .py
    print(a_exercise[ex])

# Buttons, display results & quit
btn_display = tk.Button(window, text="Display results", font=("Arial", 15))
btn_display.grid(row=1 + 2 * len(a_exercise) // 3, column=1)
btn_display.bind("<Button-1>", lambda e: display_result(e))

btn_finish = tk.Button(window, text="Quitter", font=("Arial", 15))
btn_finish.grid(row=2 + 2 * len(a_exercise) // 3, column=1)
btn_finish.bind("<Button-1>", quit)

# main loop
window.mainloop()
